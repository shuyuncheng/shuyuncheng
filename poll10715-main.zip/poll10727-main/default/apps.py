from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = 'default'
